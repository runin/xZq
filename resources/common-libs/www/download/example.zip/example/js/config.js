// 正式环境var domain_url = "http://yaotv.holdfun.cn/portal/";
var domain_url = "http://test.holdfun.cn/portal/";

var share_img = '';
var share_title = '';
var share_desc = '';
var share_page = '';

//一键关注appid
var appid = "";

// 测试号:wxc5d930ea846a40e1
var mpappid = 'wx9097d74006e67df3';

// 业务编号
var serviceNo = "tv_xxx_xxx";

// 开发环境区分业务代码
var isDev = "xxx";