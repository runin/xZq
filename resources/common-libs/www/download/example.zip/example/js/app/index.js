(function ($) {

    H.index = {
        init: function () {
            
        }
    };

    W.callbackXxxxXxx = function (data) {
    };

    H.index.init();

})(Zepto);