//测试环境
var domain_url = "http://test.holdfun.cn/portal/";
//正式环境
//var domain_url = "http://yaotv.holdfun.cn/portal/";
//本地环境
//var domain_url = "http://192.168.0.160:8080/portal/";

var resourceType = "1";
var version = "V1.0";
var share_img = "http://yaotv.qq.com/shake_tv/img/a40c225c-6cb0-488c-baf4-1f56f0e69779.png";
var share_title = "甘肃交易日";
var share_desc = "甘肃交易日，投票拿大奖，快来参与吧！";
var share_group = share_title;
var serviceNo = "tv_gansu_newstock";
var share_url = window.location.href;
var yao_avatar_size = 64;

//测试
var shaketv_appid = 'wxbf9e28ef93e7916d';
var mpappid = "wxc5d930ea846a40e1";

//正式
//var shaketv_appid = 'wx61582574b4fd0662';
//var mpappid = "wx9097d74006e67df3";

var copyright = '页面由甘肃卫视提供<br/>由新掌趣科技技术支持 & Powered by holdfun.cn';

//授权验证
var serviceNo = "tv_gansu_newstock";