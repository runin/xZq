var version = "2.3";
var share_img = "http://cdn.holdfun.cn/resources/images/fb4b1e17bb3f4a21816287e2d31132c1/2015/07/08/d218eb7462c2446a88289d6b7caae90b.jpg";
var share_title = "天天来淘金，天天抢红包！";
var share_desc = "万元现金任性抢，天降豪礼拿不停！";
var share_url = window.location.href;
var yao_tv_id = 10048;
var yao_avatar_size = 64;

var domain_url = "http://yaotv.holdfun.cn/portal/";
var business_url = "http://yao.holdfun.cn/";
var mpappid = "wx9097d74006e67df3";

//业务数据appId
var busiAppId = "wxb4196cbe04d66ab6";
//业务数据的页面类型state
var state = 5;


