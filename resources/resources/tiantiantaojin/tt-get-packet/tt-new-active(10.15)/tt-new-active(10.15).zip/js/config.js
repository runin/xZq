var version = "1.0";
var share_img = "http://cdn.holdfun.cn/mpAccount/resources/images/2015/10/15/6a3037d608b248588dda6078f062766e.jpg";
var share_title = "我试过了，真的有iphone6s送出！";
var share_desc = "等你来，我要送！";
var share_url = window.location.href;
var yao_tv_id = 10048;
var yao_avatar_size = 64;
var copyright = "新掌趣科技技术支持&amp;Powered by holdfun.cn";

//测试环境
//var business_url = "http://test.holdfun.cn/mpAccount/mobile/";
//var domain_url  ="http://192.168.0.107:8080/";
// var business_url = "http://192.168.0.42:8080/mpAccount/mobile/";
//正式环境
var domain_url = "http://yaotv.holdfun.cn/portal/";
var business_url = "http://yao.holdfun.cn/mpAccount/mobile/";
var mpappid = "wx9097d74006e67df3";

//业务数据appId
var busiAppId = "wxb4196cbe04d66ab6";
//业务数据的页面类型state
var state = 4;
