$(function() {
    var wid = $(window).width();
    var height = $(window).height();
    $("img").width(wid);
});
