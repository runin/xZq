var version = "1.1";
var share_img = "http://cdn.holdfun.cn/mpAccount/resources/images/2015/09/30/26f6728af4fe4b858c3c0d8be15cb225.jpg";
var share_title = "天天做任务，豪礼抱回家";
var share_desc = "做任务，赚金币，赢取大奖很容易！";
var share_url = window.location.href;
var yao_tv_id = 10048;
var yao_avatar_size = 64;
var copyright = "新掌趣科技技术支持&amp;Powered by holdfun.cn";

//测试环境
//var business_url = "http://test.holdfun.cn/mpAccount/mobile/";
//var domain_url  ="http://192.168.0.107:8080/";
//var business_url = "http://101.200.76.121/mpAccount/mobile/";
//正式环境
var domain_url = "http://yaotv.holdfun.cn/portal/";
// var business_url = "http://yao.holdfun.cn/mpAccount/mobile/";
var business_url = "http://tttj.holdfun.cn/mpAccount/mobile/";
var mpappid = "wx9097d74006e67df3";

//业务数据appId
var busiAppId = "wxb4196cbe04d66ab6";
//业务数据的页面类型state
var state = 14;

