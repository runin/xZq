﻿var version = "1.0";
var share_img = "http://cdn.holdfun.cn/resources/images/53a759c40d4a43318dae737d14a9ab41/2015/06/26/9784b9c2f6da4d6da71a0de5b36bf063.png";
var share_title = "拉阔新生活";
var share_desc = "锁定广州新闻频道《拉阔新生活》，奖品优惠券领不停！";
var share_url = window.location.href;
var yao_tv_id = 10079;
var yao_avatar_size = 64;

var limitSize = 10; //限制上传大小，单位

//测试环境
//var domain_url = "https://test.holdfun.cn/portal/";
//var shaketv_appid = "wxed6f8755d88bdd80";
//var mpappid = "wxc5d930ea846a40e1";

//授权验证
//var serviceNo = "tv_gznews_lkxsh";
var serviceNo = "tv_guangzhou_live";

//正式环境
var domain_url = "https://yaotv.holdfun.cn/portal/";
var shaketv_appid = "wx1ded142944ec2e92";
var mpappid = "wx9097d74006e67df3";



