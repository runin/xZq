var domain_url = "https://yaotv.holdfun.cn/portal/";
var share_img = '';
var share_title = '';
var share_desc = '';
var share_page = '';

var mpappid = 'wx9097d74006e67df3';
var shaketv_appid = "";

// 业务编号
var yao_avatar_size = 64;
var serviceNo = "tv_yaozhoubian_snsd";

// 业务代码设置
var isDev = "lordi"

//版权
var copyright = "新掌趣科技技术支持&Powered by holdfun.cn";
