
var domain_url = "http://yaotv.holdfun.cn/portal/";
var resourceType = "1";
var version = "v1.0";

var share_img = "http://cdn.holdfun.cn/resources/images/9509028bd85644418ca224b7375874dd/2015/06/10/2f245d32fe3d4437ad2e23ba22aad8c7.png";
var share_title = "云南卫视浪漫剧场《边城》正在热播，参与互动赢大礼包！";
var share_desc = "锁定云南卫视《边城》，通过微信摇一摇（电视）参与互动，答题吐槽赢大礼！";
var share_url = window.location.href;
var share_group = share_title;

//正式
var serviceNo = "tv_xwpd_news";
var copyright = "页面由昆明广播电视台提供<br>新掌趣科技技术支持&amp;Powered by holdfun.cn";
var yao_tv_id =  10467;
var follow_shaketv_appid = '';
var shaketv_appid = "";


var stationUuid = "df33f069402541d9ae070f494515154f";
var channelUuid = "818d2c167a72460caa9b4ac912416544";
var mpappid = "wx9097d74006e67df3";
