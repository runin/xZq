﻿var version = "1.0";
var share_img = "http://cdn.holdfun.cn/resources/images/af6ea3c900164b939ad7494523b52c40/2015/06/12/0afe6aebaf6d4741bce88a096baf1d98.jpg";
var share_title = "大剧威武《你是我的姐妹》";
var share_desc = "参与互动现金红包抢不停，更有威武加油卡等你来拿！";
var share_url = window.location.href;
var yao_tv_id = 10051;
var yao_avatar_size = 64;

var limitSize = 10; //限制上传大小，单位

//测试环境
//var domain_url = "http://test.holdfun.cn/portal/";
//var shaketv_appid = "wx6ffe3f8cfc8412d7";
//var mpappid = "wxc5d930ea846a40e1";


//正式环境
var domain_url = "http://yaotv.holdfun.cn/portal/";
var shaketv_appid = "wx59a1798e6ac10244";
var mpappid = "wx9097d74006e67df3";

//授权验证
var serviceNo = "tv_anhui_sister";

