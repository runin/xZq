//测试环境
//var domain_url = "http://test.holdfun.cn/portal/";
var domain_url = "http://yaotv.holdfun.cn/portal/";
var version = "V1.0";
var share_img = "http://cdn.holdfun.cn/resources/images/5bab04bffa3d4c7caa33ba23b7d06969/2015/10/23/965e9b7fd12f476684d1638818bafb0e.jpg";
var share_title = "锁定东南卫视《海峡午报》，免费抢好礼啦！";
var share_desc = "收看《海峡午报》，对着电视通过微信摇一摇（电视），免费豪礼等你来拿，快来参与吧！";
var share_group = share_title;
var share_url = window.location.href;
var serviceNo = "tv_dongnan_haixianews";
var yao_tv_id = 10041;
var follow_shaketv_appid = "wx43223c97fcd413e7";


var shaketv_appid = "wx0c280d95d5c32bf6";

var mpappid = "wx9097d74006e67df3";
var channelUuid = "a7ff2d3e97aa4473a7c7017b9602cd35";
var stationUuid = "5bab04bffa3d4c7caa33ba23b7d06969";

var yao_avatar_size = 64;  

var copyright = '页面由福建广电新媒体有限公司提供 <br>新掌趣科技技术支持&Powered by holdfun.cn';
var dev=""

