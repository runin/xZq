
var domain_url = "http://yaotv.holdfun.cn/portal/";
var mpappid = 'wx9097d74006e67df3';

// 业务编号
var serviceNo = "tv_hunan_mc";

// 业务代码设置
//var isDev = "lordi"
