
var callbackLotteryRoundHandlerData = {
    "result":true,
    "la":[
        {
            "ud":"c36eae980a784f6d8a95f7b3bd3bc849",
            "pd":"2015-06-24",
            "st":"10:10:00",
            "et":"21:8:22",
            "nst":"2015-06-24 21:09:00",
            "lc":100,
            "bi":"http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/public/lotteryactivity/images/2015624/4.jpg,http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/public/lotteryactivity/images/2015624/5.jpg,http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/public/lotteryactivity/images/2015624/d1.jpg,http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/public/lotteryactivity/images/2015624/d2.jpg,http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/public/lotteryactivity/images/2015624/d3.jpg"
        },

        {
            "ud":"c36eae980a784f6d8a95f7b3bd3bc822",
            "pd":"2015-06-24",
            "st":"21:09:00",
            "et":"21:09:05",
            "nst":"2015-06-25 19:11:39",
            "lc":100,
            "bi":"http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/public/lotteryactivity/images/2015624/4.jpg,http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/public/lotteryactivity/images/2015624/5.jpg,http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/public/lotteryactivity/images/2015624/d1.jpg,http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/public/lotteryactivity/images/2015624/d2.jpg,http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/public/lotteryactivity/images/2015624/d3.jpg"
        }
    ],
    //"sctm":1435151298000
    "sctm":1435111740000
};

var callbackLotteryLuckHandlerData = {
    'result' : true,
    'pt' : 1,
    'pv' : 1,
};