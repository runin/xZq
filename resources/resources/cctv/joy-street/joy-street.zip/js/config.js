var domain_url = "http://yaotv.holdfun.cn/portal/";

var share_img = '';
var share_title = '';
var share_desc = '';
var share_page = ''; 

var mpappid = 'wx9097d74006e67df3';

// 业务编号
var serviceNo = "tv_cctv_xlj";

var isDev = "bob";

// 预约id
var yao_tv_id = 10025;

// 一键关注
var appid = 'wx0f147dae40eef42d';