
var domain_url = "http://yaotv.holdfun.cn/portal/";
//var domain_url = "http://test.holdfun.cn/portal/";

var share_img = '';
var share_title = '';
var share_desc = '';
var share_page = ''; 

//var mpappid = 'wx9097d74006e67df3';

var mpappid = 'wx9097d74006e67df3';

// 业务编号
var serviceNo = "tv_xian_cinema";


var gameConfig = {
	
	// 加载资源
	assetsToLoader : [
		"./images/bg_contain.png",
		"./images/bg-game.jpg",
		"./images/bg-index.jpg",
		"./images/btn-lq.png",
		"./images/btn-again.png",
		"./images/btn-again-back.png",
		"./images/btn-rank.png",
		"./images/in-btn.png",

		"./images/btn-start.png",
		"./images/icon-avatar.png",
		"./images/icon-back.png",
		"./images/icon-bag.png",
		"./images/icon-boom.png",
		"./images/icon-close.png",

		"./images/icon-corn.png",
		"./images/icon-corn-disabled.png",
		"./images/icon-play.png",
		"./images/icon-play-disabled.png",
		"./images/icon-pop.png",
		"./images/icon-pop-mc.png",

		"./images/icon-pop-middle.png",
		"./images/icon-pop-middle2.png",
		"./images/icon-pop-small.png",
		"./images/icon-rank.png",
		"./images/icon-rule.png",
		"./images/icon-rule-image.png",
		
		"./images/icon-ticket.png",
		"./images/icon-ticket-disabled.png",
		"./music/bgm.mp3"
	]
};

var isDev = "lordi";