
/*---可以游戏次数---*/

$(function() {
	
  H.corn = {
	  init: function() {
		  this.entryinfo();
	  },
	  entryinfo: function() {
			getResult('api/entryinfo/info',{}, 'callbackActiveEntryInfoHandler');
	  },
  };
  
  W.callbackActiveEntryInfoHandler = function(data){
		var html = '';
		var leftA = [300];
		var leftB = [270,345];
		var leftC = [225,300,375];
		var leftD = [193,270,345,420];
		var leftE = [153,230,307,380,455];
		var leftF = [128,195,272,345,420,495];
        if(data.code == 0){
			var ep = data.ep;
			for(var i=0; i<ep; i++) {
				switch(ep) {
					case 1:
					  html += '<section class="crop stage-item" data-src="./images/icon-corn-disabled.png" data-width="41" data-height="41" data-top="525" data-left="'+leftA[i]+'"></section>';
					  break;
					  
					case 2:
					  html += '<section class="crop stage-item" data-src="./images/icon-corn-disabled.png" data-width="41" data-height="41" data-top="525" data-left="'+leftB[i]+'"></section>';
					  break;
					  
					case 3:
					  html += '<section class="crop stage-item" data-src="./images/icon-corn-disabled.png" data-width="41" data-height="41" data-top="525" data-left="'+leftC[i]+'"></section>';
					  break;
					  
					case 4:
					  html += '<section class="crop stage-item" data-src="./images/icon-corn-disabled.png" data-width="41" data-height="41" data-top="525" data-left="'+leftD[i]+'"></section>';
					  break;
					  
					case 5:
					  html += '<section class="crop stage-item" data-src="./images/icon-corn-disabled.png" data-width="41" data-height="41" data-top="525" data-left="'+leftE[i]+'"></section>';
					  break;
					  
					case 6:
					  html += '<section class="crop stage-item" data-src="./images/icon-corn-disabled.png" data-width="41" data-height="41" data-top="525" data-left="'+leftF[i]+'"></section>';
					  break;
				}
				
			}
			$("#play-con").append(html);
		}
    };
	
	H.corn.init();
  
})