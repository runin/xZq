
var domain_url = "https://yaotv.holdfun.cn/portal/";
//var domain_url = "http://test.holdfun.cn/portal/";

var share_img = '';
var share_title = '';
var share_desc = '';
var share_page = '';

//一键关注appid

var appid = "wxb721f5cd22bb16a4";
var mpappid = 'wx9097d74006e67df3';
var shaketv_appid = "wxb721f5cd22bb16a4";


// 业务编号
var serviceNo = "tv_xian_wandamly";


var gameConfig = {
	
	// 加载资源
	assetsToLoader : [
		"./images/cover_bg.jpg",
		"./images/bg_01.jpg",
		"./images/bg-game.jpg",
		"./images/play_01.png",
		"./images/play_02.png",
		
		"./images/corn_01.png",
		"./images/corn_02.png",
		"./images/icon-rule.png",
		"./images/again_btn.png",
		"./images/icon-pop-middle.png",
		"./images/icon-pop-middle2.png",
		"./images/icon-pop-small.png",
		"./images/icon-rule-image.png",
		"./images/icon-pop-mc.png",
		
		"./images/icon-boom.png",
		"./images/icon-bag.png",
		"./images/icon-pop.png",
		
		"./images/card.png",
		"./images/icon-close.png",
		
		"./images/xiexie.png",
		"./music/bgm.mp3"
		
	]
};

var isDev = "lordi";