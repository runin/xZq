;(function($) {

	H.loading = {
		percent: 0,
		$stage: $('#stage_loading'),
		$loadingBar: $('#loading_bar'),

		init: function(){
			this.resize();
			PIXI.loader.add(gameConfig.assetsToLoader);
	    	PIXI.loader.load(function(){
	    		H.loading.$loadingBar.find('p').html('加载完成');
	    		setTimeout(function(){
	    			H.loading.$stage.addClass('none');
	    			H.index.init();
					H.rule.init();
					H.record.init();
	    		},200);
	    	});
		},

		resize: function(){
			var height = $(window).height();
			this.$stage.css('height', height);
			this.$stage.removeClass('none');
			this.$loadingBar.css('top', (height - 70) / 2).removeClass('none');
			this.$stage.css('opacity', 1);
		}
	};

	H.index = {
		$stage: $('#stage_index'),
		$stages: $('.stage'),
		$play: $('#stage_index .play-btn'),
		$ruleDialog: $('#rule_dialog'),
		$rankDialog: $('#rank_dialog'),
		$bgm: $('#bgm'),
		
		game: null,
		awardList: null,
		lastScore: 0,
		isRestart: false,
		
		$cookie:null,
		$cishu:0,
		$settime:null,

		init: function(){
			$.fn.cookie('cishu',null);
			this.inBtnFn();
			this.resize();
			this.bindBtns();
			this.surplusFn();
		},
		
		inBtnFn: function() {
			$(".in-btn").click(function() {
				$(this).addClass("none");
				$("#play-con").removeClass("none");
			});
		},
		
		tipsFn: function(text) {
			var t = simpleTpl();
			t._('<div class="tips-con">'+text+'</div>')
			$("body").append(t.toString());
			setTimeout(function() {
				$(".tips-con").remove();
			},1600);
		},
		
		surplusFn: function() {//查询用户当前抽奖活动的剩余抽奖次数
			getResult('api/lottery/leftLotteryCount',{'oi': openid}, 'callbackLotteryleftLotteryCountHandler');
		},
		
		startGame: function(value){//游戏开始
		    
			this.$cishu += 1;
			$.fn.cookie('cishu', this.$cishu);
			
			this.$bgm[0].play();
			if(!this.isRestart){
				H.index.$stage.animate({opacity: 0}, 1300, 'ease');
				$('#stage_main').removeClass('none');
				$('.crop-animate-wrapper').html($('.crop.valid').last()[0]);

				setTimeout(function(){
					$('.crop-animate-wrapper .crop').css({
						'-webkit-transform': 'translate(0px,-400px)'
					});
					setTimeout(function(){
						H.index.$stage.addClass('none');
			            H.index.game = new Game();
		              	H.index.game.start({
		              		maxScore:value,
		              		endCallBack:function(score){
		              			H.index.endGame(score);
		                	}
		                });
						H.index.timeFn();
					 },1000);
				},300);
			}else{
				H.index.game.reStart({
					maxScore:value
				});
				H.index.timeFn();
			}
		},
		
		timeFn: function(value) {//一次游戏时间
			$settime = setTimeout(function() {
				 H.index.game.end({getScoreCallBack:function(score){
					 H.index.lotteryFn();
				 }});
			},30000);
		},
		
		endGame: function(score){//游戏结束
			this.lastScore = score;
			$('.crop-animate-wrapper .crop').removeClass('valid').css({
				'-webkit-transform': 'translate(0px,-0px)',
				'background-image': 'url(./images/icon-corn-disabled.png)'
			});
			H.index.$stage.append($('.crop-animate-wrapper .crop')[0]);
			H.index.$stage.append($('.crop-animate-wrapper .crop')[0]);
			clearTimeout(H.index.$settime);
			this.lotteryFn();
		},
		
		show: function(){
			this.$stage.removeClass('none');
			this.$stage.animate({opacity: 1}, 1300, 'ease');
		},
		
		bindBtns: function(){
			this.$play.unbind("click").click(function(){
				if($(this).hasClass('disabled')){
					alert("今天的游戏次数已经用完啦~");
					return;
				}
				H.index.startGame(800);
			});

			$('.again').unbind("click").click(function(){
				H.index.surplusFn();
				if($(this).hasClass('back')){
					$('#stage_main').addClass('none');
					H.index.show();
				}else{
					H.index.restartGame();
				}
				$(this).parent('.dialog-wrapper').addClass('none');
			});
		},
		
		restartGame: function() {
			this.isRestart = true;
			H.index.startGame(800);
		},

		updateLotteryCount: function(data){
			$('#stage_index .crop').css('background-image', 'url(./images/icon-corn-disabled.png)').removeClass('valid');
			
			if(data.lc > 0){
				this.$play.removeClass('disabled');
				this.$play.find('img').attr('src', './images/icon-play.png');
				for(var i = 0; i < data.lc; i++){
					if($('#stage_index .crop').eq(i).length > 0){
						$('#stage_index .crop').eq(i).css('background-image', 'url(./images/icon-corn.png)').addClass('valid');
					}else{
						break;
					}
				}
				$('.again').removeClass('none');
			}else{
				this.$play.addClass('disabled');
				this.$play.find('img').attr('src', './images/icon-play-disabled.png');
				$('.again').addClass('back').removeClass('none');
				$('.again').css('background-image', 'url(./images/btn-again-back.png)');
			}
		},

		resize: function(){
			var width = $(window).width();
			var height = $(window).height();
			var originWidth = 640;
			var originHeight = 1009;
			var xRatio = originWidth / width;
			var yRatio = originHeight / height;

			this.$stages.css({
				'width': width,
				'height': height
			});

			$('.stage-item').each(function(){
				var width = $(this).attr('data-width') / xRatio;
				var height = $(this).attr('data-height') / yRatio;
				$(this).css({
					'left' : $(this).attr('data-left') / xRatio,
					'top' : $(this).attr('data-top') / yRatio,
					'width' : width,
					'height' : height
				});
				if($(this).attr('data-src')){
					$(this).css({
						'background-image' : 'url(' + $(this).attr('data-src') + ')' ,
						'background-size': width+ 'px ' + height + 'px'
					});
				}
			});

			this.$stage.css({
				'background-image': 'url(./images/bg-index.jpg)',
				'background-size': width+ 'px ' + height + 'px'
			});

			H.rule.$ruleDialog.find('.content').css('height', height * 0.7 - 120 - 20 );

			$('#stage_main').css({
				'width': width,
				'height': height,
				'background-image' : 'url(./images/bg-game.jpg)' ,
				'background-size': width+ 'px ' + height + 'px'
			});

			this.show();
		},
		
		lotteryFn: function() {//判断是否可以抽奖
		    alert("判断是否可以抽奖:"+H.index.lastScore);
		    if(H.index.lastScore>100) {
				getResult('api/lottery/luck', {oi:openid}, 'callbackLotteryLuckHandler');
			}else {
				$("#lost_dialog").removeClass("none");
			}
			H.index.lastScore = 0;
		},
		
		receiveFn: function() {//用户领奖
			$("#receive").click(function() {
				getResult('api/lottery/award', {oi:openid}, 'callbackLotteryAwardHandler');
			});
		}
	};
	
	H.rule = {//游戏规则
		isLoaded: false,
		$ruleDialog: $('#rule_dialog'),
		$ruleOpen: $('#stage_index .rule'),
		init: function(){
			this.$ruleDialog.find('.icon-close').tap(function(){
				H.rule.hideDialog();
			});

			this.$ruleOpen.tap(function(){
				H.rule.show();
			});
		},

		show: function(){
			if(this.isLoaded){
				this.showDialog();
			}else{
				showNewLoading();
				getResult('api/common/rule',null, 'commonApiRuleHandler');	
			}
		},

		showDialog: function(){
			H.rule.$ruleDialog.removeClass('none');
			H.rule.$ruleDialog.find('.dialog').addClass('r-rule');
		},

		hideDialog: function(){
			H.rule.$ruleDialog.find('.dialog').addClass('g-rule');
			setTimeout(function(){
				H.rule.$ruleDialog.addClass('none');
				H.rule.$ruleDialog.find('.dialog').removeClass('g-rule').removeClass('r-rule');
			}, 500);
		}
	};
	
	H.record = {//中奖记录
		$stage: $('#stage_record'),
		$open: $('#stage_index .record-btn'),
		$back: $('#stage_record .back-btn'),
		$list: $('#stage_record .record-list'),
		init: function(){
			this.resize();
			this.bindBtns();
		},
		show: function(){
			this.$stage.removeClass('none');
			this.$stage.animate({opacity: 1}, 1300, 'ease');

			getResult('api/lottery/record',{
				oi: openid,
				pt: 11
			},'callbackLotteryRecordHandler');
		},

		fillList: function(data){
			if(data.result){
				var listHtml = "";
				for(var i in data.rl){
					var startTime = data.rl[i].sa.split(' ');
					var endTime = data.rl[i].ea.split(' ');
					var timeStr = "";
					if(startTime[0] && endTime[0]){
						timeStr = '有效期：' + startTime[0] + ' ~ ' + endTime[0];
					}else{
						timeStr = '';
					}
					
					listHtml += '<li><p>'+data.rl[i].pn+'</p><p class="record-code">兑换码：'+data.rl[i].cc+'</p><p class="deadline">'+timeStr+'</p></li>';
				}
	    		this.$list.html(listHtml);
	    	}else{
	    		listHtml = '<li class="placehoder"><p>&nbsp;</p><p class="record-code">暂无中奖纪录哦</p></li>';
	    		this.$list.html(listHtml);
	    	}
		},

		bindBtns: function(){
			this.$back.tap(function(){
				H.record.$stage.addClass('none');
				H.record.$stage.css('opacity', 0);
				H.index.show();
			});

			this.$open.tap(function(){
				H.index.$stage.addClass('none');
				H.index.$stage.css('opacity', 0);
				H.record.show();
			});
		},
		resize: function(){
			this.$stage.css({
				'height': 'auto',
				'min-height': $(window).height()
			});
		}
	};
	
	W.callbackLotteryleftLotteryCountHandler = function(data){//查询用户当前抽奖活动的剩余抽奖次数
		H.index.$cookie = $.fn.cookie('cishu');
		alert("剩余抽奖次数:"+H.index.$cookie);
		if(H.index.$cookie<3 && data.result){
			H.index.updateLotteryCount(data);
		}else {
			H.index.isRestart = true;
		}
	};
	
	W.callbackLotteryLuckHandler = function(data){//抽奖
	    alert("抽奖");
		if(data && data.result){
			$("#win_dialog").removeClass("none");
		}
	};
	
	W.callbackLotteryAwardHandler = function(data){//用户领奖
		if(data && data.result){
			$("#win_dialog").addClass("none");
			H.index.tipsFn("领取成功！");
		}
	};
	
	W.commonApiRuleHandler = function(data){//规则
		hideNewLoading();
		if(data.code == 0){
			H.rule.isLoaded = true;
			H.rule.$ruleDialog.find('.content').html(data.rule);
			H.rule.showDialog();
		}else{
			H.rule.hideDialog();
		}
	};
	
	W.callbackLotteryRecordHandler = function(data){//中奖记录
		H.record.fillList(data);	
	};
	
	H.loading.init();

})(Zepto);