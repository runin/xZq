var domain_url = "http://yaotv.holdfun.cn/portal/";
//var domain_url = "http://test.holdfun.cn/portal/";

var share_img = '';
var share_title = '';
var share_desc = '';
var share_page = window.location.href;

//一键关注appid
var appid = "wx43223c97fcd413e7";
var mpappid = 'wx9097d74006e67df3';
var shaketv_appid = "wxe2ca2cf669263ba0"; 
// 业务编号
var serviceNo = "tv_fjtv_winner";
// 业务代码设置
var isDev = "bob";
var yao_tv_id = 10138;
