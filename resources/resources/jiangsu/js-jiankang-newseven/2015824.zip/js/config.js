var version = "1.0";
var share_img = '';
var share_title = '';
var share_desc = '';
var share_page = '';
var share_url = window.location.href;
var yao_tv_id = 10128;
var yao_avatar_size = 64;

var domain_url = "http://yaotv.holdfun.cn/portal/";
var shaketv_appid = "wx4b46bf1e1dc44ddd";
var mpappid = 'wx9097d74006e67df3';

// 业务编号
var serviceNo = "tv_jiangsu_jiankang";

// 业务代码设置
//var isDev = "lordi"
