var domain_url = "http://jsws.holdfun.cn/portal/"; 
var auth_domain_url = 'http://yaotv.holdfun.cn/portal/';
// var auth_serviceNo = 'tv_pingdingshan_bobtest';
var auth_serviceNo = 'tv_jiangsu_jscw';
var petServiceNo = "tv_jiangsu_pet";

var share_img = '';
var share_title = '';
var share_desc = '';
var share_page = '';

// 业务编号
var mpappid = 'wx9097d74006e67df3';

var defaultTopic = "本轮互动话题：缘分就是有趣的人和事";

var version = '150';

var COOKIE_KEY_OPENID = mpappid + '_openid' + version;
var COOKIE_KEY_SHAKE_OPENID = '';
var COOKIE_KEY_HOLDFUN_AUTHED = 'holdfun_authed' + version;

var COOKIE_KEY_NICKNAME = mpappid + '_nickname' + version;
var COOKIE_KEY_AVATAR = mpappid + '_headimgurl' + version;

var LS_KEY_FIRST_VISIT_PV_PREFIX = 'pv_' + version;
var LS_KEY_CARD_PREFIX = 'cid_' + version;
var LS_KEY_COMMENT_PRAISED_PREFIX = 'comment_praised_' + version;
var LS_KEY_UNLOCKING_PREFIX = 'unlock_cid_' + version;
var LS_KEY_GUIDE = 'is_guided_' + version;
var LS_KEY_PET_ID = 'pet_id_' + version;
var LS_KEY_DIDI = 'didi_accepted_' + version;

var LS_KEY_COMMENT_CACHE_FRIEND = 'comment_cache_friend_'  + version;
var LS_KEY_COMMENT_CACHE_TIME = 'comment_cache_time_'  + version;
var LS_KEY_COMMENT_CACHE_QU = 'comment_cache_qu_'  + version;