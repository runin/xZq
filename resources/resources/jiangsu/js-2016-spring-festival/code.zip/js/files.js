{
  "files": [{
    "source": "https://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/bg-card.png",
    "type": "IMAGE",
    "size": 97.1
  },{
    "source": "https://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/dialog-cover-bottom.png",
    "type": "IMAGE",
    "size": 83.9
  },{
    "source": "https://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/bg-cover-top.jpg",
    "type": "IMAGE",
    "size": 82.0
  },{
    "source": "https://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/bg-cover-bottom.jpg",
    "type": "IMAGE",
    "size": 80.4
  },{
    "source": "https://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/icon-fu.png",
    "type": "IMAGE",
    "size": 72.4
  },{
    "source": "https://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/bg-yao-bottom.jpg",
    "type": "IMAGE",
    "size": 70.8
  },{
    "source": "https://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/bg-fu.jpg",
    "type": "IMAGE",
    "size": 66.8
  },{
    "source": "https://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/dialog-cover-top.png",
    "type": "IMAGE",
    "size": 64.3
  },{
    "source": "https://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/bg-card-small.png",
    "type": "IMAGE",
    "size": 61.6
  },{
    "source": "https://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/bg-yao-top.jpg",
    "type": "IMAGE",
    "size": 44.1
  }, {
    "source": "https://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/bg-main.jpg",
    "type": "IMAGE",
    "size": 26
  }, {
    "source": "http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/greetingcard/material/images/2016112/01dd1fff398b4d74ba88ec1af9c7ae9c.png",
    "type": "IMAGE",
    "size": 26
  }, {
    "source": "http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/greetingcard/material/images/2016112/c26868c0bfd7408fab4ed80c1cbdcf1c.png",
    "type": "IMAGE",
    "size": 26
  }, {
    "source": "http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/greetingcard/material/images/2016112/d6b9ec0bb7e34d929e1894b71e9ddddc.png",
    "type": "IMAGE",
    "size": 26
  }, {
    "source": "http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/greetingcard/material/images/2016112/5a847227f862466e8b845d400004717a.png",
    "type": "IMAGE",
    "size": 26
  }]
}