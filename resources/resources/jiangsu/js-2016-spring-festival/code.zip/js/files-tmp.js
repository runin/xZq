{
  "files": [
  	{
	    "source": "./images/avatar.jpg",
	    "type": "IMAGE",
	    "size": 97.1
  	},{
      "source": "./images/icon-voice-bg.jpg",
      "type": "IMAGE",
      "size": 97.1
    },{
      "source": "./images/icon-voice-left.png",
      "type": "IMAGE",
      "size": 97.1
    },{
      "source": "./images/icon-voice-right.png",
      "type": "IMAGE",
      "size": 97.1
    },{
      "source": "http://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/bg-card.png",
      "type": "IMAGE",
      "size": 97.1
    },{
      "source": "http://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/bg-card-small.png",
      "type": "IMAGE",
      "size": 97.1
    },{
      "source": "http://yaotv.qq.com/shake_tv/auto2/2016/01/957pprijv1qnhi/images/bg-main.jpg",
      "type": "IMAGE",
      "size": 97.1
    },{
  		"type":"SCRIPT",
  		"source":"http://cdn.holdfun.cn/jsws2016video/video.min.js",
  		"size":213.9
    }]
}
