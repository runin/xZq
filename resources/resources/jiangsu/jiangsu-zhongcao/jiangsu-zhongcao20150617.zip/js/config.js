﻿//测试环境
var domain_url = "http://test.holdfun.cn/portal/";

//正式环境
//var domain_url = "http://yaotv.holdfun.cn/portal/";
var resourceType = "1";
var version = "1.0";

var share_img = "http://cdn.holdfun.cn/resources/images/4160bcaf21e9495f9cf17fe9689f5bbb/2015/04/23/1856b90edc5c4d9d9abd4b518b7a9751.png";
var share_title = "江苏体育休闲频道中超直播！";
var share_desc = "关注体育，助威中超，尽在江苏体育休闲频道！";
var share_url = window.location.href;

var share_group = share_title;
var yao_avatar_size = 64;

//测试环境
var shaketv_appid = 'wx6ac25764cb9ef145';
var mpappid = "wxc5d930ea846a40e1";

//正式环境
//var shaketv_appid = "wx4b46bf1e1dc44ddd";
//var mpappid = "wx9097d74006e67df3";

var weixin_appid = 'wxed0f712040b969bf'; // 一键关注电视台公众号ap

var copyright = '页面由江苏体育休闲频道提供<br/>新掌趣科技技术支持 & Powered by holdfun.cn';

//授权验证
var serviceNo = "tv_jiangsu_ff";





