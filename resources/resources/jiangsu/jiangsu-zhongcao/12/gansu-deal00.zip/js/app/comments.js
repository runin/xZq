//*
 /* 评论页*/
 
(function($) {
	H.comments = {
		$main : $('#main'),
		$lottery_time : $(".lottery-time"),
		$nav : $(".nav"),
		$top_back : $(".top-back"),
		actUid : null,
		page : 0,
		beforePage : 0,
		item_index : 0,
		pageSize:5,
		commActUid:null,
		loadmore : true,
		isCount : true,
		now_time : null,
		expires: {expires: 7},
		init : function(){
			var me = this;
			//me.count_down();
			//me.current_time();
			//me.currentCommentsAct();
			me.event_handler();
		},
		event_handler: function() {
			var me = this;
			/*this.$main.delegate('.show-all', 'click', function(e) {
				e.preventDefault();
				var $class_all = $(this).parent('div').find('.all-con');

				$class_all.find('span').toggleClass('all');
				if( $class_all.find('span').hasClass('all')){
					$(this).text('^显示全部');
				}else{
					$class_all.css('height','auto');
					$(this).text('^收起');
				}
			});*/
			this.$lottery_time.click(function(e){
				e.preventDefault();
				if(H.comments.$lottery_time.attr("disabled") != 'disabled' && openid != null){
					H.lottery.lottery(H.comments.actUid,2);
					
				}
			});
			this.$top_back.click(function(e){
				e.preventDefault();
				$(window).scrollTop(0);
				$(this).addClass('none');
			});

			$(window).scroll(function(){
				var scroH = $(this).scrollTop(),
					$fix = $('.fix');
				if(scroH > 0){
					$fix.removeClass('none');
					me.$top_back.removeClass('none');
				}else if(scroH == 0){
					$fix.addClass('none');
					me.$top_back.addClass('none');
				}
			});
			
			var range = 55, //距下边界长度/单位px
			maxpage = 100, //设置加载最多次数
			totalheight = 0;
			$(window).scroll(function(){
				
			    var srollPos = $(window).scrollTop();
			    totalheight = parseFloat($(window).height()) + parseFloat(srollPos);
				if (($(document).height() - range) <= totalheight  && H.comments.page < maxpage && H.comments.loadmore) {

					if (!$('#mallSpinner').hasClass('none')) {
						return;
					}
					
					H.comments.getList(H.comments.page);
			    }
			});
			
			$("#send").click(function(){
				if(!$.trim($("#comments-info").val())){
					alert('请填写评论');
					$("#comments-info").focus();
					return;
				}
				if(openid != null){
					$("#send").attr("disabled","disabled");
					$("#comments-info").attr("disabled","disabled");
					if(headimgurl != null && headimgurl.indexOf("./images/avatar.jpg") > 0){
						headimgurl='';
					}
					
					getResult('comments/save', {
						co:encodeURIComponent($("#comments-info").val()),
						op:openid,
						tid:pid,
						ty:2,
						pa:null,
						nickname: encodeURIComponent(nickname || ''),
						headimgurl: headimgurl || ''
						}, 'callbackCommentsSave',true);
				}
			});
			
		},
		getList:function(page){
			if(page - 1  == this.beforePage){
				$('#mallSpinner').removeClass('none');
				W.showLoading();
				getResultAsync('comments/list', {page:page,ps:this.pageSize,anys:pid,op:openid,zd:0,kind:0}, 'callbackCommentsList');
			}
		},
		
		bindZanClick: function(cls){
			$("."+cls).click(function(){
				if($(this).hasClass('z-ed')){ return; }
				$(this).addClass("curZan").addClass('z-ed');
				getResult('comments/praise', {
					uid:$(this).parent().parent().attr("data-uuid"),
					op:openid
					}, 'callbackCommentsPraise',true);
			});
		},
		is_show: function(i){
			var $all_con = $('#all-con' + i);
			var height = $all_con.height(),
				inner_height = $all_con.find('span').height();
			if(inner_height > height){
				$all_con.find('span').addClass('all');
				$('#show-all' + i).removeClass('none');
			}
		},
		
		tpl: function(data) {
			var me = this, t = simpleTpl(), item = data.items || [], $top_comment = $('#top-comment'),$nor_comment = $('#nor-comment');
			for (var i = 0, len = item.length; i < len; i++) {
				var isZan = item[i].isp ? "z-ed":"";
				t._('<li data-uuid = "'+ item[i].uid +'">')
					._('<img src="'+ (item[i].im ? (item[i].im + '/' + yao_avatar_size) : './images/avatar.jpg')+'"/>')
					._('<div class="review-text">')
						//._('<label class="zan '+isZan+'" data-collect="true" data-collect-flag="cd-express-comments-zan" data-collect-desc="点赞" >'+ item[i].pc +'</label>')
						._('<h3>'+ (item[i].na || '匿名用户') +'</h3>')
						._('<p class="all-con" id="all-con'+ me.item_index +'">')
							._('<span>'+ item[i].co +'</span>')
						._('</p>')
						//._('<a class="show-all none" id="show-all'+ me.item_index +'" data-collect="true" data-collect-flag="cd-express-comments-show" data-collect-desc="评论收缩显示" >^显示全部</a>')
					._('</div>')
					._('</li>');
				++ me.item_index;
			}
			if(data.kind == 1){
				$top_comment.append(t.toString());
			}else{
				$nor_comment.append(t.toString());
			}
			for (var i = 0, len = me.item_index; i < len; i++) { me.is_show(i); }
			H.comments.bindZanClick("zan");
		},
		currentPrizeAct:function(){
			//获取抽奖活动
			var prizeActList = prizeAct.activity,
				prizeLength = prizeAct.activity.length,
				nowTimeStr = H.comments.now_time,
				me = this,
				$lottery_time_h1 = me.$lottery_time.find("a");

			if(comptime(nowTimeStr,prizeActList[0].ap+" "+prizeActList[0].ab) > 0){
				$lottery_time_h1.html('距离下次摇奖开启还剩：');
				H.comments.$lottery_time.find('i').removeClass('swing');
				H.comments.$lottery_time.find('i').addClass('lottery-timed');
				H.comments.$lottery_time.attr("disabled","disabled");
				$('.detail-countdown').attr('stime',timestamp(nowTimeStr)).attr('etime',timestamp(prizeActList[0].ap+" "+prizeActList[0].ab));
				this.actUid = prizeActList[0].au;
				return;
			}
			if(comptime(prizeActList[prizeLength-1].ap+" "+prizeActList[prizeLength-1].ae,nowTimeStr) > 0){
				$lottery_time_h1.html('今日摇奖已结束，明天再来吧');
				H.comments.$lottery_time.find('i').removeClass('swing');
				H.comments.$lottery_time.find('i').addClass('lottery-timed');
				H.comments.$lottery_time.attr("disabled","disabled");
				H.comments.isCount = false;
				$('.detail-countdown').addClass('none');
				return;
			}

			for ( var i = 0; i < prizeActList.length; i++) {
				var beginTimeStr = prizeActList[i].ap+" "+prizeActList[i].ab;
				var endTimeStr = prizeActList[i].ap+" "+prizeActList[i].ae;
				if(comptime(nowTimeStr,beginTimeStr) < 0 && comptime(nowTimeStr,endTimeStr) >=0){
					this.actUid = prizeActList[i].au;
					getResult('express/haslottery', {openid:openid,actUid:prizeActList[i].au}, 'expressHasLotteryHandler');
					return;
				}else if(comptime(nowTimeStr,beginTimeStr) >= 0){
					$lottery_time_h1.html('距离下次摇奖开启还剩：');
					H.comments.$lottery_time.find('i').addClass('lottery-timed');
					H.comments.$lottery_time.find('i').removeClass('swing');
					H.comments.$lottery_time.attr("disabled","disabled");
					$('.detail-countdown').attr('stime',timestamp(nowTimeStr)).attr('etime',timestamp(beginTimeStr));
					if(i< prizeActList.length -1){
						this.actUid = prizeActList[i+1].au;
					}
					return;
				}
			}
		},
		 //倒计时
		/*count_down : function() {
			$('.detail-countdown').each(function() {
				var $me = $(this);
				$(this).countDown({
					etpl : '%H%' + '<label class="dian">:</label>' + '%M%' + '<label class="dian">:</label>' + '%S%', // 还有...结束
					stpl : '%H%' + '<label class="dian">:</label>' + '%M%' + '<label class="dian">:</label>' + '%S%', // 还有...开始
					sdtpl : '',
					otpl : '',
					otCallback : function() {
						setTimeout(function(){
							if(H.comments.isCount){
								H.comments.current_time();
							}
						},1000);

					},
					sdCallback :function(){
						var h1 = $('.detail-countdown label:nth-child(1)'),
							h2 = $('.detail-countdown label:nth-child(2)'),
							h3 = $('.detail-countdown label:nth-child(3)');

						if (h1.text() == 0 && h2.text() == 0){
							h1.hide();
							h2.hide();
							h3.hide();
						}
					}
				});
			});
		},*/
		
		currentComments : function(commActUid) {
			getResultAsync('comments/count', {anys:commActUid}, 'callbackCommentsCount',true);
			getResultAsync('comments/list', {page:1,ps:this.pageSize,anys:commActUid,op:openid}, 'callbackCommentsList',true);
			
		}
	};

	W.expressHasLotteryHandler = function(data){
		if(data.code == 0){
			var prizeActList = prizeAct.activity,
				index = null,
				nowTimeStr = H.comments.now_time,
				$lottery_time_h1 = H.comments.$lottery_time.find("a");

			for ( var i = 0; i < prizeActList.length; i++) {
				if(H.comments.actUid == prizeActList[i].au){
					index = i;
					break;
				}
			}
			if(data.result){
				if(index >= (prizeActList.length-1)){
					$lottery_time_h1.html('今日摇奖已结束，明天再来吧');
					H.comments.$lottery_time.find('i').removeClass('swing');
					H.comments.$lottery_time.find('i').addClass('lottery-timed');
					H.comments.isCount = false;
					H.comments.$lottery_time.attr("disabled","disabled");
					$('.detail-countdown').addClass('none');
				}else{
					$lottery_time_h1.html('距离下次摇奖开启还剩：');
					H.comments.$lottery_time.find('i').removeClass('swing');
					H.comments.$lottery_time.find('i').addClass('lottery-timed');
					H.comments.$lottery_time.attr("disabled","disabled");
					$('.detail-countdown').attr('stime',timestamp(nowTimeStr)).attr('etime',timestamp(prizeActList[index+1].ap+" "+prizeActList[index+1].ab));
					H.comments.actUid = prizeActList[index+1].au;
				}
			}else{
				$lottery_time_h1.html('距离此次摇奖结束：');
				H.comments.$lottery_time.find('i').addClass('swing').removeClass('lottery-timed');
				H.comments.$lottery_time.removeAttr("disabled");
				$('#lottery').removeClass('none');
				$('.detail-countdown').attr('stime',timestamp(nowTimeStr)).attr('etime',timestamp(prizeActList[index].ap+" "+prizeActList[index].ae));
				H.comments.actUid = prizeActList[index].au;
			}
		}
	}
	
	

	W.callbackCommentsCount = function(data){
		if(data.code == 0){
			$('.review-count').find("label").html(data.tc);
		}
	}
	
	W.callbackCommentsList = function(data){
		$('#mallSpinner').addClass('none');
		W.hideLoading();
		if(data.code == 0){
			H.comments.tpl(data);
			if (data.items.length < H.comments.pageSize && data.kind == 0) {
				H.comments.loadmore = false;
			}
			if(data.items.length == H.comments.pageSize){
				if(H.comments.page == 0){
					H.comments.beforePage = 1;
					H.comments.page = 2;
				}else{
					H.comments.beforePage = H.comments.page;
					H.comments.page++ ;
				}
			}
		}else {
		}
	}
	
	W.callbackCommentsSave = function(data){
		
		if(data.code == 0 ){
			var headImg = null;
			if(headimgurl == null || headimgurl == ''){
				headImg = './images/avatar.jpg';
			}else{
				headImg = headimgurl + '/' + yao_avatar_size;
			}
			var t = simpleTpl(),$nor_comment = $('#nor-comment');
			t._('<li id="'+ data.uid +'" data-uuid = "'+ data.uid +'">')
			._('<img src="'+ headImg +'"/>')
			._('<div class="review-text">')
			._('<h3>'+ (nickname || '匿名用户') +'</h3>')
			._('<p class="all-con" id="all-con'+ data.uid +'">')
				._('<span>'+ $("#comments-info").val() +'</span>')
			._('</p>')
			._('</div>')
			._('</li>');

			if($nor_comment.children().length==0){
				$nor_comment.append(t.toString());
			}else{
				$nor_comment.children().first().before(t.toString());
			}
			H.comments.is_show(data.uid);
			$("#comments-info").val("");
			H.comments.bindZanClick("zan-"+data.uid);
			$('.review-count').find("label").html($('.review-count').find("label").html()*1+1);

			var navH = $("#"+data.uid).offset().top;
			$(window).scrollTop(navH);
			$("#send").removeAttr("disabled");
			$("#comments-info").removeAttr("disabled");
		}else{
			alert(data.message);
			$("#comments-info").val("");
			$("#send").removeAttr("disabled");
			$("#comments-info").removeAttr("disabled");
		}
	}
	
	W.callbackCommentsPraise = function(data){
		if(data.code == 0){
			$(".curZan").text($(".curZan").text()*1 + 1);
			$(".curZan").removeClass("curZan");
		}
	}
	
	W.callbackTimeHandler = function(data){
		H.comments.now_time = data.tm;
		//H.comments.currentPrizeAct();
	}
})(Zepto);
$(function(){
	H.comments.init();
});