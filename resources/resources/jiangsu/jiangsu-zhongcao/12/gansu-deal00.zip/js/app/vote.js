// JavaScript Document
var pid;

$(function() {
	var setime;
	var cmp = true;
	var N = {
        showPage: function (pageName, fn, pMoudel) {
            var mps = $(".page");
            mps.addClass("none");
            mps.each(function (i, item) {
                var t = $(item);
                if (t.attr("id") == pageName) {
                    t.removeClass("none");
                    N.currentPage = t;
                    if (fn) {
                        fn(t);
                    };
                    return false;
                }
            })
        },
		//接口管理
        loadData: function (param) {
            W.showLoading();
            var p = $.extend({ url: "", type: "get", async: false, dataType: "jsonp", jsonp: "callback" }, param);
            var connt = 0;
            var cbName = "";
            var cbFn = null;
            for (var i in param) {
                connt++;
                if (connt == 2) {
                    cbName = i;
                    cbFn = param[i];
                    break;
                }
            }
            if (cbName && cbFn && !W[cbName]) { W[cbName] = cbFn; }
            $.ajax({ type: p.type, data: param.data, async: p.async, url: p.url, dataType: p.dataType, jsonp: p.jsonp, jsonpCallback: cbName,
                success: function () {
                    W.hideLoading();
                },
                error: function () {
                    if (param.error) { param.error() };
                    W.hideLoading();
                }
            });
        },
        module: function (mName, fn) {
            !N[mName] && (N[mName] = new fn());
        } 
    };
	
	N.module("mvote", function(){
		this.idClass = function() {
			this.win = $(window);
			this.content = $(".content");
			this.myrecord = $("#my-record");
			this.lotterybtn = $("#lottery-btn");
			this.lotterylist = $("#lottery-list");
			this.lotterycon = $(".lottery-text .lotterycon");
			this.onreceive = $(".onreceive");
			this.votebtn = $("#vote-btn");
			this.radiospan = $(".radio-span");
			this.stitle = $("#s-title");
			this.voteresult = $("#vote-result");
			this.inquireinto = $("#inquire-into");
			this.countdown = $(".countdown")
		}
		
		//最小高度
		this.minheight = function() {
			this.idClass();
			var self = this;
			var winh = self.win.height();
			this.content.css("min-height",winh-100);
		}
		//赞助商品牌图片
		this.sponsor  = function() {
			N.loadData({url: domain_url+'gansu/stock/brand',callbackGansuStockBrand:function(data){
				if(data.code == 0){
					$(".mingren").append("<img src='"+data.brand+"' />").removeClass("none");
				}
			}});
			
			if(headimgurl) {
				$("#myuser img").attr("src",headimgurl+"/"+yao_avatar_size);
			}else {
				$("#myuser img").attr("src","images/touxiang.png");
			}
		}
		
		//我的战绩
		this.onRule = function() {
			var self = this;
			self.myrecord.click(function(e) {
				e.preventDefault();
				 N.loadData({url: domain_url+'gansu/stock/transcript',callbackGansuStockTranscript:function(data){

					 if(data.code == 0) {
						 H.dialog.record.open("累计参与<span class='red'>"+data.jc+"</span>次<br /><span class='font14'>共获积分<span class='red'>"+data.iv+"</span>分，全国排第<span class='red'>"+data.rank+"</span>名</span>");
					 }else {
						 H.dialog.record.open("您暂无战绩哦！别灰心，加油"); 
					 }
				},data: {
					yoi:openid
				  }
				});
				
			});
		}
		
		//接口判断
		this.voiedata = function() {
			var self = this;
			N.loadData({url: domain_url+'gansu/stock/info',callbackGansuStockInfo:function(data){
				
				if(openid && data.code == 0) {

					var pstime = data.pst; //该期播放开始时间
					var petime = data.pet; //该期播放结束时间
					var cuttime = data.cut; //当前系统时间
					//var c = new Date(); //当前本地时间
					//var cuttime = c.getFullYear()+"-"+(c.getMonth()+1)+"-"+c.getDate()+" "+c.getHours()+":"+c.getMinutes()+":"+c.getSeconds();
					var ps = timestamp(pstime);//该期播放开始毫秒
					var pe = timestamp(petime);//该期播放结束毫秒
					var pc = timestamp(cuttime);//系统时间毫秒
					var qitems = data.qitems;
					
					//$("#nor-comment").empty();
					if(cmp == true) {
					    pid = data.pid;
					    H.comments.currentComments(pid);
						cmp = false;
					}
									
					if(qitems && pc>ps && pc<pe) {
						self.timeTm(data,pc,pe);
					}else {
						self.stitle.addClass("none");
						self.inquireinto.addClass("none");
						self.voteresult.addClass("none");
						self.countdown.removeClass("none");
						self.lotterybtn.addClass("none");
						$("#vote-cd").text("今日抽奖已结束，明天再来吧");
					}
				}
			},data: {
				yoi:openid 
			  }
			});
		};
		
		
		//获取题目
		var timer = 0;
		var nexttime = 0;
		this.timeTm = function(data,pc,pe){
			var self = this;
			var qitems = data.qitems;
			clearInterval(setime);
			for(var i=0; i<qitems.length; i++) {
				var qstime = qitems[i].qst;//开始时间
				var qetime = qitems[i].qet;//结束时间
				var qs = timestamp(qstime);//开始秒
				var qe = timestamp(qetime);//结束秒
				var qcode = qitems[i];//是否参与过
				var aitems = qitems[i].aitems;
				
				if(pc>qs && pc<qe) {
					timer = qe-qs;
					self.showTm(data, qitems[i].qt, aitems.length, qitems[i].aitems, qcode);	
					if(qcode.qcode == 1) {//假如这题目已经投过票了
						self.qcodeR();//投票比例
						
						if(i<(qitems.length-1)){
							nexttime=timestamp(qitems[i+1].qst);
							self.setTm(parseInt(nexttime-pc),"离下次抽奖还剩");
							setTimeout(function(){
								self.voiedata();
							},parseInt(qe-pc+1)*1000);
						}else {
							$("#vote-cd").text("今日抽奖已结束，明天再来吧");
							//clearInterval(setime);
							setTimeout(function(){
								self.voiedata();
							},parseInt(qe-pc+1)*1000);
						}
						return;	
					}
					
					self.setTm(parseInt(qe-pc),"离下次抽奖还剩");
					setTimeout(function(){
						self.voiedata();
					},parseInt(qe-pc+1)*1000);

					return;	
				}
				
				if(pc<qs) {
					self.stitle.addClass("none");//题目
					self.inquireinto.addClass("none");//选项列表
					self.voteresult.addClass("none");//投票结果
					self.countdown.removeClass("none");//定时
					self.setTm(parseInt(qs-pc),"投票抽奖倒计时");
					setTimeout(function(){
						self.voiedata();
					},parseInt(qs-pc+1)*1000);
					return;
				}

				if(pc>=timestamp(qitems[qitems.length-1].qet)) {
					self.stitle.addClass("none");
					self.inquireinto.addClass("none");
					self.voteresult.addClass("none");
					self.countdown.removeClass("none");
					self.lotterybtn.addClass("none");
					clearInterval(setime);
					$("#vote-cd").text("今日抽奖已结束，明天再来吧");
					return;
				}	
			}
		};
		
		//每个时间点的题目
		this.showTm = function(data, vtitle, aitems, atlist, qcode) {
			var self =this;
			var vote = [];
			var result = [];
			var scconut = 0;//总支持数
			self.stitle.removeClass("none");
			self.inquireinto.removeClass("none");
			self.voteresult.addClass("none");
			self.countdown.addClass("none");
			self.stitle.text(vtitle);
			self.stitle.attr("id",qcode.quid);

			for(var t=0; t<aitems; t++) {
				vote.push('<span id="'+atlist[t].auid+'" class="radio-span">'+atlist[t].at+'</span>');
				result.push("<h5>"+atlist[t].at+"</h5><p><span class='r-ratio'><em id='sc"+t+"'></em></span> <span class='r-number' id='pc"+t+"'></span> </p>");
				scconut += atlist[t].sc;
			}
			$("#vote").empty().append(vote.join(''));
			$(".result").empty().append(result.join(''));
			self.clickradio(atlist, scconut, qcode, aitems);
		};
		
		//选择答案
		var checkid = 0;
		this.clickradio = function(atlist, scconut, qcode, aitems) {
			var self = this;
			var index = 0;
			$("#vote").delegate('.radio-span',"click",function(e) {
				e.preventDefault();
				$(this).addClass("on").siblings().removeClass("on");
				index = $(this).index();
				checkid =  $(this).attr("id");
			});
			self.voteBtn(index, atlist ,scconut, qcode, aitems);
		};

		
		//比例计算
		this.voteBtn = function(index, atlist, scconut, qcode, aitems) {
			var self = this;
			$(".content").delegate('#vote-btn',"click",function(e) {
				e.preventDefault();
				if(!$("#vote .radio-span").hasClass("on")) {
					//alert("请选择您要投票的选项！");
					H.dialog.error.open("请选择您要投票的选项！");
					return;
				}
				var c = new Date(); //当前系统时间
				var cuttime = c.getFullYear()+"-"+(c.getMonth()+1)+"-"+c.getDate()+" "+c.getHours()+":"+c.getMinutes()+":"+c.getSeconds();
				var pc = timestamp(cuttime);//系统时间毫秒
				//voteTime(pc);
				
				var sq = qcode.qcode;
				localStorage.setItem(sq,1);
				
				N.loadData({url: domain_url+'gansu/stock/answer',callbackGansuStockAnswer:function(data){
					if(data.code == 0) {
						var atCount = 0;
						self.stitle.removeClass("none");
						self.inquireinto.addClass("none");
						self.voteresult.removeClass("none");
						self.countdown.addClass("none");
						
						atCount = atlist[index].sc+1;
						for(var s=0; s<atlist.length; s++) {
							$("#sc"+s).css("width",Math.round(atlist[s].sc / (scconut+1) * 10000) / 100.00 + "%");
							$("#pc"+s).text(Math.round(atlist[s].sc / (scconut+1) * 10000) / 100.00 + "%");
						}
						$("#sc"+index).css("width",Math.round(atCount / (scconut+1) * 10000) / 100.00 + "%");
						$("#pc"+index).text(Math.round(atCount / (scconut+1) * 10000) / 100.00 + "%");
						
					}
				},data: {
					yoi: openid,
					auid: checkid
				}
			 });
			 self.lotteryLq();
		  });
		 // self.lottery();
		};
		
		//定时器
		/*this.voteTime = function(pc){
			if(nexttime != 0) {
				setTm(parseInt(nexttime-pc),"投票抽奖倒计时");
				setTimeout(function(){
					voiedata();
				},parseInt(nexttime-pc)*1000);
			}else {
				$("#vote-cd").text("今日抽奖已结束，明天再来吧");
			}
		};*/
		
		//倒计时
		this.setTm = function(nowt,text){
			clearInterval(setime);
			setime = setInterval(function(){
				var day=0,
				    hour=0,
				    minute=0,
				    second=0;//时间默认值
						
				if(nowt > 0){
					day = Math.floor(nowt / (60 * 60 * 24));
					hour = Math.floor(nowt / (60 * 60)) - (day * 24);
					minute = Math.floor(nowt / 60) - (day * 24 * 60) - (hour * 60);
					second = Math.floor(nowt) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
				}
				if (minute <= 9) minute = '0' + minute;
				if (second <= 9) second = '0' + second;
				$("#vote-cd").text(text+": "+hour+":"+minute+":"+second);
				nowt--;
			},1000);
			//clearInterval(setime);
		};
		
		
		//投票比例
		this.qcodeR = function() {
			  var self = this;
			  self.stitle.removeClass("none");
			  self.inquireinto.addClass("none");
			  self.voteresult.removeClass("none");
			  self.countdown.removeClass("none");
			  self.lotterybtn.addClass("none");
			  var quid = self.stitle.attr("id");
			  var setsu;

			  N.loadData({url: domain_url+'gansu/stock/support',callbackGansuStockSupport:function(data){
				  if(data.code == 0) {
					  function support() {
						  clearInterval(setsu);
						  var scconut = 0;
						  for(var i=0; i<data.aitem.length; i++) {
							  scconut += data.aitem[i].sc;
						  }
						  for(var t=0; t<data.aitem.length; t++) {
							  $("#sc"+t).css("width",Math.round(data.aitem[t].sc / scconut * 10000) / 100.00 + "%");
							  $("#pc"+t).text(Math.round(data.aitem[t].sc / scconut * 10000) / 100.00 + "%");
						  }
						 setsu = setTimeout(support,100000);
					  };
					  support();

				  }
			  },data:{
				  quid:quid
			  }});
			
		};
		
		//点击抽奖
		this.lotteryLq = function() {
			var self = this;
			self.lotterybtn.click(function(e) {
				
				e.preventDefault();
				self.lotteryBtn();
			});
		}
		
		//抽奖
		this.lotteryBtn = function() {
			var liboxa = [];
			liboxa.push("<section class='lottery-box' id='lottery-box'>");
			liboxa.push("<div class='lottery-text' id='lottery'>");
			liboxa.push("<a href='###' class='a-close'></a>");
			liboxa.push("<h4>猛击一张卡片试试手气吧！</h4>");
			liboxa.push("<ul id='items'>");
			for(var i=0; i<6; i++) {
				liboxa.push("<li id='li"+i+"'><div class='lotterycon'>");
				liboxa.push("<em></em>");//宝箱
				liboxa.push("<label class='none'></label>");//中奖的奖品
				liboxa.push("<span class='onreceive none'>点击领取</span>");
				liboxa.push("<span class='mask none'></span>");
				liboxa.push("</div></li>");
			}
			liboxa.push("</ul></div>");
			
			liboxa.push("<div class='lottery-text none' id='podium'>");
			liboxa.push("<a href='###' class='a-close'></a>");
			liboxa.push("<div class='trophy line' id='prizes'><img src='' /></div>");
			liboxa.push("<div class='trophyname' id='prizesName'></div>");
			liboxa.push("<p class='podium-input'><input name='' type='text' class='text-b' id='rn-name' placeholder='姓名' /></p>");
			liboxa.push("<p class='podium-input'><input name='' type='text' class='text-b' id='ph-phone' placeholder='手机号码' /></p>");
			liboxa.push("<p class='podium-input'><input name='' type='text' class='text-b' id='ad-address' placeholder='地址' /></p>");
			liboxa.push("<p class='mt25 center'><input name='' type='button' class='btn-c' id='btn-podium' value='立即领取' /></p>");
			liboxa.push("</div>");
			
			liboxa.push("<div class='lottery-text none' id='lottery-success' >");
			liboxa.push("<a href='###' class='a-close'></a>");
			liboxa.push("<div class='trophy'><span id='trophyimg'></span></div>");
			liboxa.push("<h3 id='winning'></h3>");
			liboxa.push("<p class='podium-text'></p>");
			liboxa.push("<p class='mt15 center'><input name='' type='button' class='btn-c' id='btn-bls' value='返回首页' /></p>");
			liboxa.push("</div>");
			
			liboxa.push("</section>");
			$("body").append(liboxa.join(""));
			this.lotteryCon();
			this.closepop();
		};
		
		//打开宝箱
		this.openbox = function(zpi, zpn, ditems, that) {
			
			var inthis = that.parent().attr("id");
			$("#"+inthis).addClass("on").find("label").removeClass("none");
			$("#"+inthis).parent("li").addClass("lion");
			$("#"+inthis).find("label").css({"background":"url('"+zpi+"')","background-repeat":"no-repeat","background-position":"center","background-size":"90% auto"});
			$("#"+inthis).find("em").addClass("none");
			//$("#"+inthis).find(".onreceive").removeClass("none");
			$("#"+inthis).find(".mask").removeClass("none").addClass("maskon").text(zpn);
			
			//for(var t=0; t<ditems.length; t++) {
			//	$("#items li").not($("#"+inthis)).eq(t).find("label").css({"background":"url('"+ditems[t].pi+"')","background-repeat":"no-repeat","background-position":"center","background-size":"90% auto"});
			//	$("#items li").not($("#"+inthis)).eq(t).find(".mask").removeClass("none").text(ditems[t].pn);
			//}
		}
		
		//判断是否中奖
		this.lotteryCon = function() {
			var self = this;
			$(".lotterycon").unbind("click").click(function(e) {
				e.preventDefault();
				var titleId = $("#s-title").attr("id");
				var that = $(this);
				//var onthis = $(".lotterycon").index(this);
				
				//var inthis;
				N.loadData({url: domain_url+'gansu/stock/lottery',callbackGansuStockLottery:function(data){
					var ditems = data.items;
					var urlimg = "images/cry.png";
				    var urltext = " ";
					switch(data.code) {
						case 0:
							self.openbox(data.pi, data.pn, ditems, that);
							that.find(".onreceive").removeClass("none");
							$("#winning").text("恭喜您，获得"+data.pn+"-"+data.pu);
							$("#prizesName").text(data.pn);
							self.recerve(data.ph, data.rn, data.ad, data.pi, data.des);
							break
						case -1:
							//alert(data.message);
							self.openbox(urlimg, urltext, ditems, that);
							break
						case 1:
							//alert(data.message);
							self.openbox(urlimg, urltext, ditems, that);
							break
						case 2:
							//alert(data.message);
							//$("#lottery-box").remove();
							self.openbox(urlimg, urltext, ditems, that);
							//self.voiedata();
							break
					}
					//$(".lotterycon").children("em").addClass("none");
					$(".lotterycon").children("label").removeClass("none");
					$(".lotterycon").unbind("click");

				},data:{
					yoi: openid,
					puid: titleId
				  }
				});
			});
		};
		
		//点击领取
		this.recerve = function(ph, rn, ad, pi, des) {
			var self = this;
			$("#lottery-box").delegate(".maskon","click",function(e) {
				e.preventDefault();
				$("#lottery").addClass("none");
				$("#podium").removeClass("none");
				$("#lottery-success").addClass("none");
				$("#prizes img").attr("src",pi);
				$(".podium-text").text(des);
				self.psuccess(ph, rn, ad, pi);
			});
		};

		//关闭弹层
		this.closepop = function() {
			var self = this;
			$("body").delegate(".a-close","click",function() {
				//liboxa = [];
				if($(".mask").hasClass("maskon")) {
					//self.qcodeR();
					self.voiedata();
				}
				$("#lottery-box").remove();
			});
			//self.returnblsLuck();
		}

		//填写领奖品
		this.psuccess = function(ph, rn, ad, pi) {
			var self = this;
			$("#lottery-box").delegate("#btn-podium","click",function(e) {
					e.preventDefault();
					var src = $("#items li.lion label").find("img").attr("src");
					var $rnName =$("#rn-name");
					var trnName = $.trim($rnName.val());
					var $phPhone = $("#ph-phone");
					var tphPhone = $.trim($phPhone.val());
					var $adAddress = $("#ad-address");
					var tadAddress = $.trim($adAddress.val());
					
					//$.trim($rnName.val(rn));
					//$.trim($phPhone.val(ph));
					//$.trim($adAddress.val(ad));
					
					if (!trnName) {//姓名
						//H.dialog.poptips.open("请填写姓名！");
						alert("请填写姓名！");
						$rnName.focus();
						return false;
					}
					if (!tphPhone) {//手机号码
						//H.dialog.poptips.open("请填写手机号码！");
						alert("请填写手机号码！");
						$phPhone.focus();
						return false;
					}
					if (!/^\d{11}$/.test(tphPhone)) {//手机号码格式
						//H.dialog.poptips.open("这手机号，可打不通...！");
						alert("这手机号，可打不通...！");
						$phPhone.focus();
						return false;
					}
					if (tadAddress.length < 5 || tadAddress.length > 60) {//地址
						//H.dialog.poptips.open("地址长度应在5到60个字！");
						alert("地址长度应在5到60个字！");
						$adAddress.focus();
						return false;
					}
					
					N.loadData({url: domain_url+'gansu/stock/award',callbackGansuStockAward:function(data){
						
						if(data.code == 0) {
							$("#lottery").addClass("none");
							$("#podium").addClass("none");
							$("#lottery-success").removeClass("none");
							$("#trophyimg").append("<img src='"+pi+"' />");
						}else {
							alert('提交失败！');
							//H.dialog.poptips.open("提交失败！");
						}
						
				},data:{
					yoi: openid,
					ph: ph,
					rn: rn,
					ad: ad
				   }
				});

			});
			
			self.returnblsLuck();
		}
		
		
		//返回首页
		this.returnblsLuck = function() {
			var self = this;
			$("body").delegate("#btn-bls","click",function(e) {
				e.preventDefault();
			    self.voiedata();
				$("#lottery-box").remove();
			});
		}

		this.init = function() {
			this.minheight();
			this.sponsor();
			this.voiedata();
			this.onRule();
			
		}
		this.init();	
	});
	
	/*if(openid && openid!=null) {
		window['shaketv'] && shaketv.subscribe(weixin_appid, function(returnData){
			//alert('shaketv subscribe: ' + JSON.stringify(returnData));
		});
	}*/
})