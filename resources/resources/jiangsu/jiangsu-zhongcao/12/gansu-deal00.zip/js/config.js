//测试环境
//var domain_url = "http://test.holdfun.cn/portal/";
//正式环境
var domain_url = "http://yaotv.holdfun.cn/portal/";
//本地环境
//var domain_url = "http://192.168.0.160:8080/portal/";

var resourceType = "1";
var version = "V1.0";
var share_img = "http://yaotv.qq.com/shake_tv/img/a40c225c-6cb0-488c-baf4-1f56f0e69779.png";
var share_title = "甘肃交易日";
var share_desc = "甘肃交易日，投票拿大奖，快来参与吧！";
var share_group = share_title;
var serviceNo = "gansu-deal";

var share_url = window.location.href;

var yao_avatar_size = 64;

//测试
//var shaketv_appid = 'wxbf9e28ef93e7916d';

//正式
var shaketv_appid = 'wxe2ca2cf669263ba0';

var copyright = '页面由甘肃交易日提供<br/>新掌趣科技制作  Powered by holdfun.cn';
