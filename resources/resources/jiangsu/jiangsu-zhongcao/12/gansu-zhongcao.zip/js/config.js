﻿//测试环境
var domain_url = "http://test.holdfun.cn/portal/";
//var domain_url = "http://192.168.0.102/portal/";

//正式环境
//var domain_url = "http://yaotv.holdfun.cn/portal/";
var resourceType = "1";
var version = "1.0";

var share_img = "http://cdn.holdfun.cn/resources/images/82ae9a00a5d349ae8f47b102cbdf00d7/2015/03/27/422fdd7c6fc14340a805e037754e5dac.jpg";
var share_title = "甘肃中超";
var share_desc = "甘肃中超";
var share_url = window.location.href;

var share_group = share_title;
var serviceNo = "tv_gansu_newstock";
var yao_avatar_size = 64;

//var shaketv_appid = 'wxbf9e28ef93e7916d';

//正式环境
//var shaketv_appid = "wx61582574b4fd0662";
var shaketv_appid = "wxa4516877e8e04f1b";

var weixin_appid = 'wxed0f712040b969bf'; // 一键关注电视台公众号ap

var copyright = '页面由央视新闻提供<br/>由新掌趣科技技术支持 & Powered by holdfun.cn';



