var auth_domain_url = "http://yaotv.holdfun.cn/portal/";
//var auth_domain_url = "https://test.holdfun.cn/portal/";

var share_img = 'http://cdn.holdfun.cn/resources/images/4160bcaf21e9495f9cf17fe9689f5bbb/2015/03/05/eeda88d02e8c4d2388b9a542cf00f3fe.jpg';
var share_title = '呼叫盟友一起建立萌宠王国';
var share_desc = '这里竟然只有我自己？也不知道是喜是悲，总之等你一起来！';
var share_page = '';

//一键关注appid
var appid = "wxf78babd70d9a1a1e";
var mpappid = 'wx9097d74006e67df3';
var shaketv_appid = "wxf78babd70d9a1a1e";

//var serviceNo = "tv_jiangsu_tangyuan";
var serviceNo = "tv_jiangsu_pet";

//var yao_tv_id = 10184;
var yao_avatar_size = 64;
var copyright = "页面由江苏频道提供 & Powered by holdfun.cn";
var isDev = "lordi";

//时间
var $time = "2016-02-08 00:00:00";
var domain_url = "http://jsws.holdfun.cn/portal/";

//var domain_url = "http://yaotv.holdfun.cn/portal/";
//var domain_url = "http://192.168.0.169/portal/";
