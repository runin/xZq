var domain_url = "http://yaotv.holdfun.cn/portal/";

var resourceType = "1";
var version = "V1.0";
var share_img = "http://cdn.holdfun.cn/resources/images/9681fd5401f24bd0b1215a47aa75ebcb/2015/01/12/d83536aa604e4e3a98f2ff0f4be741d2.jpg";
var share_title = "芝麻开门";
var share_desc = "芝麻开门";
var share_group = share_title;
var share_url = window.location.href; 
var shaketv_appid = "wx622d31bdcc738280";
var yao_tv_id = 51079;

var mpappid = "wx9097d74006e67df3";
var serviceNo = "tv_jszhima_opensesame";