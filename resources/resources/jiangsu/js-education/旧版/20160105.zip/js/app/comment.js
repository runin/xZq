
//****//
//***评论***//
var plcolor = [
{
	id:0,
	color:"#c0ff00"
},{
	id:1,
	color:"#00deff"
},{
	id:2,
	color:"#fff600"
},{
	id:3,
	color:"#ffffff"
},{
	id:4,
	color:"#ff13f7"
},{
	id:5,
	color:"#4fe637"
}];

(function($) {
	H.conmment = {
		$ps: 5,//每次获取实时消息的条数
		$maxid:0,//最大的id
		$uuid:[],//自己评论的uuid
		$hcud:null,
		init: function() {
			this.nowtimtFn();
			this.commentBntFn();
		},
		nowtimtFn: function() {//查询当前系统时间
		    getResult('api/common/timestr', {}, 'commonApiTimeStrHandler');
		},
		htmlFn: function() {
			var t = simpleTpl();
			t._('<section class="pop-bg">')
			t._('<div class="comment-box in-up">')
			t._('<div class="comment-list">')
			t._('<ul id="nor-comment">')
			t._('</ul>')
			t._('</div>')
			t._('<div class="comment-form">')
			t._('<a href="javascript:void(0);" class="gohome"></a>')
			t._('<input name="" type="text" class="comment-input" id="c-input" placeholder="说说你的看法吧~" />')
			t._('<input name="" type="button" id="send" class="comment-btn" />')
			t._('</div>')
			t._('</div>')
			t._('</section>')
			$("body").append(t.toString());
			this.sendFn();
			this.gohomeFn();
		},
		gohomeFn: function() {
			$(".gohome").click(function() {
				$(".comment-box").removeClass("in-up").addClass("out-down");
				setTimeout(function() {
					$(".pop-bg").remove();
				},500);
			});
		},
		commentBntFn: function() {
			var that = this;
			$("#comment-btn").click(function() {
				that.htmlFn();
				that.heightFn();
				that.roomFn();
			})
		},
		heightFn: function() {//计算高度
			var wh = $(window).height();
			$("body,.pop-bg:before,.main-box,.comment-box").css("height",wh);
		},
		sendFn: function() {//保存评论
			$("body").unbind("click").delegate("#send","click",function(e) {
				var $cipt = $("#c-input");
				var cipt = $.trim($("#c-input").val());
				if(!cipt) {
					showTips("请填写你的看法！");
					$cipt.focus();
					return;
				}
				if(openid != null) {
					$("#send").attr("disabled","disabled");
					$("#c-input").attr("disabled","disabled");
					if(headimgurl != null && headimgurl.indexOf("./images/avatar.jpg") > 0){
						headimgurl='';
					}
					getResult('api/comments/save', {op:openid, co:encodeURIComponent(cipt), ty:2, pa:null, nickname: encodeURIComponent(nickname || ''), headimgurl: headimgurl || ''}, 'Callback：callbackCommentsSave');
				}
			});
		},
		roomFn: function() {//实时获取评论信息
			getResult('api/comments/room', {ps:H.conmment.$ps, maxid:H.conmment.$maxid}, 'Callback：callbackCommentsRoom');
			setInterval(function() {
				getResult('api/comments/room', {ps:H.conmment.$ps, maxid:H.conmment.$maxid}, 'Callback：callbackCommentsRoom');
			},3000);
		},
		removeFn: function(classid) {//定时清除每一条评论
			setTimeout(function() {
				$("#"+classid).remove();
			},3500)
		}
	};
	
	W.commonApiTimeStrHandler = function(data) {//获取系统当前时间串
	    H.conmment.$hcud = data.t;
	}
	
	W.callbackCommentsSave = function(data) {//保存评论
	    if(data&&data.code == 0){
			var headImg = null;
			if(headimgurl == null || headimgurl == ''){
				headImg = './images/avatar.jpg';
			}else{  
				headImg = headimgurl + '/' + yao_avatar_size;
			}
			var t = simpleTpl();
			var $nor_comment = $('#nor-comment');
			H.conmment.$uuid.push(data.uid);
			t._('<li class="remove" id="'+data.uid+'" data-uuid = "'+data.uid+'">')
			t._('<div class="comment-bar">')
			t._('<i class="i-headimg" style="background-image:url('+headImg+')"></i>')
			t._('<p>'+$("#c-input").val()+'</p>')
			t._('</div>')
			t._('</li>')
			
			if($nor_comment.children().length==0){
				$nor_comment.append(t.toString());
			}else{
				$nor_comment.children().last().after(t.toString());
			}
			H.conmment.removeFn(data.uid);
			
			$("#send").removeAttr("disabled");
			$("#c-input").removeAttr("disabled").val("");
				
		}else {
			alert("提交失败，请稍候再试~");
			$("#c-input").val("");
			$("#send").removeAttr("disabled");
			$("#c-input").removeAttr("disabled");
		}
	};
	
	W.callbackCommentsRoom = function(data) {//实时获取评论信息
	     if(data&&data.code == 0){
			 var t = simpleTpl();
			 var html = "";
			 var ay = [];
			 var ar = [];
			 var k = "";
			 var leg = 0;
			 var $nor_comment = $('#nor-comment');
			 var items = data.items;
			 var time;
			 var now =  parseInt(timestamp(H.conmment.$hcud));
			 H.conmment.$maxid = data.maxid;
			 for(var i=0, leg=items.length; i<leg; i++) {
				 time = parseInt(timestamp(items[i].at));
				 var s = H.conmment.$uuid.some(function(item, index, array) {//如果自己的评论就不再实时获取
					return (item==items[i].uid);
				 })
				 if(s || now>time) {
					 continue;
				 }
				 var c = Math.floor((Math.random()*plcolor.length));//字体颜色
				 ay.push('<li class="remove" id="'+items[i].id+'" data-uuid = "'+items[i].uid+'">');
				 ay.push('<div class="comment-bar">');
				 ay.push('<i class="i-headimg" style="background-image:url('+items[i].im+')"></i>');
				 ay.push('<p style="color:'+plcolor[c].color+'">'+items[i].co+'</p>');
				 ay.push('</div>')
				 ay.push('</li>')
				 H.conmment.removeFn(items[i].id);
			 }
			 leg = ay.length;
			 for(var i=0,leg = ay.length; i<leg; i++) {
				 k += ay[i];
				 if(i!=0 && ((i+1)%6==0)) {
					 ar.push(k);
					 k="";
				 }
			 }
			 if($nor_comment.children().length==0){
				 $nor_comment.append(ar.reverse().join(""));
			 }else{
			 	$nor_comment.children().last().after(ar.reverse().join(""));
			 }
		 }
	}
	
	H.conmment.init();
  
})(Zepto);