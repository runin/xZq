(function($) {
	
	H.reserve = {
		init: function() {
			// showLoading();
		}
	};

	W.callbackXxxxXxx = function(data) {
	};

	H.reserve.init();

})(Zepto);