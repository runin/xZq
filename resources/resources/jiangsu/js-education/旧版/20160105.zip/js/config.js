var domain_url = "https://yaotv.holdfun.cn/portal/";
// var domain_url = "https://test.holdfun.cn/portal/";

var share_img = '';
var share_title = '';
var share_desc = '';
var share_page = '';

//一键关注appid
var appid = "wx8172be554b269be7";
var mpappid = 'wx9097d74006e67df3';
var shaketv_appid = "wx8172be554b269be7";
var ad_id = "tv_jsjy_quan";

// 业务编号
var serviceNo = "tv_jiangsujiaoyu_quantai";
//var serviceNo = "tv_jiangsu_quantai";

// 业务代码设置
var yao_tv_id = 10184;

var yao_avatar_size = 64;

var copyright = "页面由江苏教育频道提供 & Powered by holdfun.cn";

var isDev = "bob";