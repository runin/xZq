﻿var version = "2.3";
var share_img = "http://yaotv-test.oss-cn-shenzhen.aliyuncs.com/resources/images/e41875a9dfef45adb7281c025197a957/2015/05/18/41647ba91f50474a85944b0b55ce2c7d.png";
var share_title = "深圳卫视-厨房的秘密";
var share_desc = "万元好礼任性派，就在深圳卫视《厨房的秘密》！";
var share_url = window.location.href;

var yao_avatar_size = 64;

var copyright = "页面由深圳卫视提供";

//测试环境
//var domain_url = "http://test.holdfun.cn/portal/";
//var shaketv_appid = "wx4e4ed0f61ea6d29c";
//var mpappid = "wxc5d930ea846a40e1";


//正式环境
var domain_url = "http://yaotv.holdfun.cn/portal/";
var shaketv_appid = "wx028e76a8342017a4";
var mpappid = "wx9097d74006e67df3";

//授权验证
var serviceNo = "tv_szws_kitchen_secret";
